CREATE TABLE book (
book_id int primary key,
title varchar(30) not null,
category varchar(30) not null,
author varchar(30) not null
);

CREATE TABLE student (
student_id int primary key,
name varchar(30) not null,
dept_name varchar(30) not null,
year int not null,
semester int not null
);

CREATE TABLE issue (
student_id int references student(student_id),
book_id int references book(book_id),
issue_date date not null,
return_date date
);

INSERT INTO book VALUES ('1', 'first_title', 'first_category', 'first_author');
INSERT INTO book VALUES ('2', 'second_title', 'second_category', 'second_author');

INSERT INTO student VALUES ('1', 'first_student', 'first_dept', '2018', '1');
INSERT INTO student VALUES ('2', 'second_student', 'second_dept', '2018', '1');
INSERT INTO student VALUES ('3', 'third_student', 'second_dept', '2018', '1');

INSERT INTO issue VALUES ('1', '1', '2018-02-11', '2018-03-12');
INSERT INTO issue VALUES ('1', '2', '2018-02-11', '2018-03-12');
INSERT INTO issue VALUES ('2', '1', '2018-02-11', '2018-03-12');
INSERT INTO issue VALUES ('2', '2', '2018-02-11', '2018-03-12');
INSERT INTO issue VALUES ('3', '2', '2018-02-11', '2018-03-12');