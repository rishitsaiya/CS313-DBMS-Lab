import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class IssueServlet
 */
@WebServlet("/IssueServlet")
public class IssueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
	
		//getting input values from jsp page
		String s_id = request.getParameter("s_id");
		String book_id = request.getParameter("b_id");
		String issue_date = request.getParameter("issue_date");
	
		Connection con = null;
 		String url = "jdbc:postgresql://localhost:5432/library"; //PostgreSQL URL and followed by the database name
 		String username = "postgres"; //PostgreSQL username
 		String password = "123456"; //PostgreSQL password
		
		Class.forName("org.postgresql.Driver");
		con = DriverManager.getConnection(url, username, password); //attempting to connect to PostgreSQL database
 		System.out.println("Printing connection object "+con);
		

		PreparedStatement st1 = con .prepareStatement("select * from student where student_id=?");
		st1.setString(1,s_id);
		ResultSet rs=st1.executeQuery();
		int studentExists=0
		while(rs.next())
		{
		studentExists++;
		}
		System.out.println(studentExists);
		if(studentExists>0)
		{
		//Prepared Statement to add student book issue data
		PreparedStatement st = con .prepareStatement("insert into issue values(?, ?,?,?)");
 		st.setString(1,s_id);
		st.setString(2,book_id);
		st.setDate(3,java.sql.Date.valueOf(issue_date));
		st.setString(4,null);
		int result=st.executeUpdate();

		//Checks if insert is successful.If yes,then redirects to Result.jsp page 
		if(result>0)
		{
			
			RequestDispatcher rd = request.getRequestDispatcher("IssueResult.jsp");
			rd.forward(request, response);
		}
		}
		else
		{
		System.out.println("no student found");
		}
		}
		 catch (Exception e) 
 		{
 			e.printStackTrace();
 		}

	
	}


}


