
import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException; 
import java.sql.*;
public class GrdReport
{  
	static int studentCount=0,passCount=0,FailCount=0;
	
	public static void main(String[] args)    
	{  
		Student student=new Student();
		String line = "";  
		String splitBy = ",";  
		try   
		{  
		//parsing a CSV file into BufferedReader class constructor  
			BufferedReader br = new BufferedReader(new FileReader("GradeReport.csv"));  
			while ((line = br.readLine()) != null)   //returns a Boolean value  
			{  
				String[] data = line.split(splitBy);    // use comma as separator  
				int courseCount=student.checkCourseRunning(data[1],data[2],data[3],data[4]);
				if(courseCount>=1)
				{
					System.out.println("The course  "+data[1]+"  exists\n");
					int studentEnrolled=student.checkStudentRegistered(data[0]);
					if(studentEnrolled>=1)
					{
						student.updateGradeAndCredits(data[0],data[1],data[2],data[3],data[4],data[5]);
						getCount(data[0],data[5]);
					}
				}
			}  
			System.out.println("No of students enrolled for the course  "+studentCount+"\nThe number of students passed "+passCount+"\nThe number of students failed "+FailCount);
		}   
		catch (IOException e)   
		{  
			e.printStackTrace();  
		} 
		catch (SQLException e)   
		{  
			e.printStackTrace();  
		}
}


//Function to get count of number of students enrolled for course,no of students passed & failed
public static void getCount(String id,String grade)
{
	 studentCount++;
	 if(!(grade.equals("F")))
	 {
		 passCount++;
	 }
	 if((grade.equals("F")))
	 {
		 FailCount++;
	 }
}
} 
