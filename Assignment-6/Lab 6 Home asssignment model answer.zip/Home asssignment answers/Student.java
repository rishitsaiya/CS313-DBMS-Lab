import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Student {
	static Connection conn;
	static PreparedStatement ps;
	static ResultSet rs;
	
	//Function to check if course is running
	public  int checkCourseRunning(String course_id,String sec_id, String semester,String year) throws SQLException 
	{
		int isCourseRunning=0,count=0; 
		conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/university", "postgres", "123456");
		try
		{
			ps=conn.prepareStatement("select course_id,sec_id,semester,year from takes where course_id=? and sec_id=? and semester=? and year=?");//check course is running 
			ps.setString(1, course_id);
		  	ps.setString(2, sec_id);
		  	ps.setString(3, semester);
		  	ps.setInt(4, Integer.valueOf(year));
		  	rs=ps.executeQuery();
			while(rs.next()) {
				count++;
			}
			isCourseRunning=count;
			}
		 catch(Exception e) 
		{
			e.printStackTrace();
		}
		return isCourseRunning;
	}

	
	
//Function to check if student is registered 	
public  int checkStudentRegistered(String id) 
{
		int count=0,isStudentRegistered=0; 
		try{
		  	conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/university", "postgres", "123456");
		  	ps=conn.prepareStatement("select id from takes where id=?");//check if student is registered 
		  	ps.setString(1,id);
		  	rs=ps.executeQuery();
			while(rs.next()) {
				count++;
			}
			isStudentRegistered=count;
			
		}
		 catch(Exception e) {
			e.printStackTrace();
		}
		return isStudentRegistered;
}

	
//Function to update grade in takes table and incrementing credits if grade is not equal to F
public  void updateGradeAndCredits(String id,String course_id,String sec_id,String semester,String year,String grade) {
	try{
		  conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/university", "postgres", "123456");
	      ps=conn.prepareStatement("update takes set grade=? where course_id=? and sec_id=? and year=? and semester=? and id=?;");//update grade for given course_id and id
		  ps.setString(1, grade);
		  ps.setString(2, course_id);
		  ps.setString(3, sec_id);
		  ps.setInt(4, Integer.valueOf(year));
		  ps.setString(5, semester);
		  ps.setString(6,id);
		  int isGradeUpdated=ps.executeUpdate();
		  if(!(grade.equals("F"))) {
		  ps=conn.prepareStatement("update student set tot_cred =tot_cred + ( select credits from course where course_id =?) where id=?;");//increment tot_credits if grade not equal to F
		  ps.setString(1,course_id);
		  ps.setString(2,id);
		  int isCreditsUpdated=ps.executeUpdate();
			}
		  }
		 catch(Exception e) {
				e.printStackTrace();
		 }
	}
}
